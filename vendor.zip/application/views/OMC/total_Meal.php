
<div class="container mt-5">
    <table class="table table-sm table-light">
        <thead class="table-info text-primary">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Date</th>
                <th scope="col">Total Meal</th>
                <th scope="col">Posted User</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($totalMeal as $meal) {
                ?>
                <tr> 
                    <th scope="row"><?php echo ++$counter; ?></th>
                    <td><?php echo $meal->date ?></td>
                    <td ><?php echo $meal->count ?></td>
                    <td><?php echo $meal->user ?></td>
                </tr>
            <?php } ?>


            <tr class="bg-primary text-light">
                <td style="text-align: right;">Total Meal</td>
                <td class="text-danger">=</td>
                <?php
                $count = 0;
                foreach ($totalMeal as $total) {
                    $count += $total->count;
                }
                ?>
                <td colspan="1" class="text-warning"><?php echo $count; ?></td>
                <td>
                    <a href="<?php echo base_url() ?>Welcome/getPDF" class="btn btn-success border-warning pt-1 pb-1">Get PDF</a>
                </td>

            </tr>
        </tbody>
    </table>
</div>